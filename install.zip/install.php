<?php
// error_reporting(0);

$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
$use_ssh = isset($_REQUEST['ssh_id']) ? 1 : 0;
$url = isset($_POST['url']) ? $_POST['url'] : "";
$path = isset($_POST['path']) ? $_POST['path'] : "";
$xoops_lib = isset($_POST['xoops_lib']) ? $_POST['xoops_lib'] : "";
$xoops_data = isset($_POST['xoops_data']) ? $_POST['xoops_data'] : "";
$home = isset($_POST['home']) ? $_POST['home'] : "";
$trust_path = isset($_POST['trust_path']) ? $_POST['trust_path'] : "";

switch ($op) {
    case "install_xoops":
        install_xoops($use_ssh, $home, $trust_path, $xoops_lib, $xoops_data);
        break;

    default:
        install_setup();
        break;
}

function get_xoops_path()
{

    $path = dirname($_SERVER['SCRIPT_FILENAME']) . "/";
    $path = str_replace('\\', '/', $path);
    if (substr($path, -1) == '/') {
        $path = substr($path, 0, -1);
    }
    $xoops_path['path'] = $path;
    $url = str_replace('install.php', '', 'http://' . $_SERVER["HTTP_HOST"] . $_SERVER['REQUEST_URI']);
    if (substr($url, -1) == '/') {
        $url = substr($url, 0, -1);
    }
    $xoops_path['url'] = $url;

    if (strpos($path, '/home') !== false) {
        $dir_arr = explode("/", $path);
        $home = "{$dir_arr[0]}/{$dir_arr[1]}/{$dir_arr[2]}/{$dir_arr[3]}/";
    } else {
        $home = str_replace('\\', '/', $_SERVER["DOCUMENT_ROOT"]);
    }
    $trust_path = dirname($home);
    $xoops_path['home'] = $home;
    $xoops_path['trust_path'] = $trust_path;

    $www_dir = substr($path, strlen("{$home}"));
    if (substr($www_dir, 0, 1) == '/') {
        $www_dir = substr($www_dir, 1);
    }

    $subdir = str_replace('/', '_', $www_dir);
    if (empty($subdir)) {
        $subdir = "xoops";
    }

    $xoops_path['subdir'] = $subdir;
    $xoops_path['xoops_lib'] = "{$trust_path}/{$subdir}_lib";
    $xoops_path['xoops_data'] = "{$trust_path}/{$subdir}_data";
    return $xoops_path;
}

function install_setup()
{

    $xoops_path = get_xoops_path();
    // die(var_dump($xoops_path));
    foreach ($xoops_path as $key => $value) {
        $$key = $value;
    }

    $is_writable = is_writable($path);
    $is_trust_path_writable = is_writable($trust_path);

    $ssh_input = "";
    if (!$is_writable) {

        $_COOKIE['ssh_id'] = isset($_COOKIE['ssh_id']) ? $_COOKIE['ssh_id'] : "";
        $_COOKIE['ssh_pass'] = isset($_COOKIE['ssh_pass']) ? $_COOKIE['ssh_pass'] : "";
        $_COOKIE['ssh_port'] = isset($_COOKIE['ssh_port']) ? $_COOKIE['ssh_port'] : "22";

        $ssh_input = "
        <div class='alert alert-info'>
            <div class='form-group form-group-lg'>
                <label class='col-sm-2 control-label'>ssh 帳號：</label>
                <div class='col-sm-2'>
                <input type='text' name='ssh_id' value='{$_COOKIE['ssh_id']}' placeholder='ssh 帳號' class='form-control input-lg'>
                </div>
                <label class='col-sm-2 control-label'>ssh 密碼：</label>
                <div class='col-sm-3'>
                <input type='password' name='ssh_pass' value='{$_COOKIE['ssh_pass']}' placeholder='請輸入 ssh 密碼' class='form-control input-lg'>
                </div>
                <label class='col-sm-1 control-label'>port：</label>
                <div class='col-sm-2'>
                <input type='text' name='ssh_port' value='{$_COOKIE['ssh_port']}' placeholder='輸入 port' class='form-control input-lg'>
                </div>
            </div>
            請確定輸入的ssh帳號是否有存取 $trust_path 及 $path 目錄權限，否則建議用 root 身份來安裝。
        </div>
        ";
    }

    $phpversion = phpversion();
    $php_note = "（<span class='text-success'>PHP > 5.3.9，可以安裝。</span>）";
    if (version_compare(phpversion(), '5.3.9', '<')) {
        $php_note = "（<span class='text-danger'>PHP 版本太舊，必須 5.3.9 以上才能安裝。</span>）";
    }

    $form = "
      <form action='{$_SERVER['PHP_SELF']}' method='post' class='form-horizontal' role='form'>
        <div class='form-group form-group-lg'>
          <label class='col-sm-4 control-label'>PHP版本</label>
          <div class='col-sm-8'>
            <p class=\"form-control-static\">{$phpversion}{$php_note}</p>
          </div>
        </div>
        <div class='form-group form-group-lg'>
          <label class='col-sm-4 control-label'>XOOPS_URL（網站網址）</label>
          <div class='col-sm-8'>
              <p class=\"form-control-static\">{$url}</p>
          </div>
        </div>
        <div class='form-group form-group-lg'>
          <label class='col-sm-4 control-label'>XOOPS_ROOT_PATH（安裝路徑）</label>
          <div class='col-sm-8'>
              <p class=\"form-control-static\">{$path}</p>
          </div>
        </div>


        <div class='alert alert-warning'>

            <div class='form-group form-group-lg'>
              <label class='col-sm-4 control-label'>網頁目錄為</label>
              <div class='col-sm-8'>
                <input type='text' name='home' value='{$home}' placeholder='網頁目錄' class='form-control input-lg'>
              </div>
            </div>
            <div class='form-group form-group-lg'>
              <label class='col-sm-4 control-label'>網頁目錄外（安全目錄）為</label>
              <div class='col-sm-8'>
                <input type='text' name='trust_path' value='{$trust_path}' placeholder='安全目錄' class='form-control input-lg'>
              </div>
            </div>
            <div class='form-group form-group-lg'>
              <label class='col-sm-4 control-label'>xoops_lib目錄（須在網頁目錄外）</label>
              <div class='col-sm-8'>
                  <input type='text' name='xoops_lib' value='{$xoops_lib}' placeholder='xoops_lib目錄（須在網頁目錄外）' class='form-control input-lg'>
              </div>
            </div>
            <div class='form-group form-group-lg'>
              <label class='col-sm-4 control-label'>xoops_data目錄（須在網頁目錄外）</label>
              <div class='col-sm-8'>
                  <input type='text' name='xoops_data' value='{$xoops_data}' placeholder='xoops_data目錄（須在網頁目錄外）' class='form-control input-lg'>
              </div>
            </div>
        </div>

        {$ssh_input}

        <div class='text-center'>
          <input type='hidden' name='op' value='install_xoops'>
          <button type='submit' class='btn btn-primary'>送出</button>
        </div>
      </form>
      ";

    $main = "
    <!DOCTYPE html>
    <html>
    <head>
    <title>XOOPS快速安裝</title>
    <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css' integrity='sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7' crossorigin='anonymous'>

    <!-- Optional theme -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css' integrity='sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r' crossorigin='anonymous'>

    <!-- Latest compiled and minified JavaScript -->
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js' integrity='sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS' crossorigin='anonymous'></script>
    <style>
      body{
        font-size:1.5em;
        font-family: 微軟正黑體;
      }
    </style>
    </head>
    <body>
    <div class='row'>
      <div class='col-sm-2'></div>
      <div class='col-sm-8'>
        <h1 class='text-center text-info'>XOOPS輕鬆架快速安裝</h1>
        <hr>
        $form
      </div>
      <div class='col-sm-2'></div>
    </div>

    </body>
    </html>
    ";

    die($main);
}

function install_xoops($use_ssh = 0, $home = "", $trust_path = "", $xoops_lib = "", $xoops_data = "")
{
    if ($use_ssh != 0) {
        if (!empty($_POST['ssh_id'])) {
            setcookie("ssh_id", $_POST['ssh_id']);
        }
        if (!empty($_POST['ssh_pass'])) {
            setcookie("ssh_pass", $_POST['ssh_pass']);
        }
        if (!empty($_POST['ssh_port'])) {
            setcookie("ssh_port", $_POST['ssh_port']);
        } else {
            $_POST['ssh_port'] = 22;
        }

        // set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');

        include 'vendor/autoload.php';
        $ssh = new \phpseclib3\Net\SSH2('127.0.0.1', $_POST['ssh_port']);

        if ($ssh->login($_POST['ssh_id'], $_POST['ssh_pass'])) {
            // die('ssh_install');
            ssh_install($ssh, $home, $trust_path, $xoops_lib, $xoops_data);
        } else {
            // die('php_install');
            php_install($home, $trust_path, $xoops_lib, $xoops_data);
        }

    } else {
        php_install();
    }

    $xoops_url = str_replace('install.php', 'index.php', 'http://' . $_SERVER["HTTP_HOST"] . $_SERVER['SCRIPT_NAME']);

    header("location: {$xoops_url}");
    exit;
}

function ssh_install($ssh, $home = "", $trust_path = "", $xoops_lib = "", $xoops_data = "")
{
    // error_reporting(-1);
    $xoops_path = get_xoops_path();
    foreach ($xoops_path as $key => $value) {
        if (empty($$key)) {
            $$key = $value;
        }
    }

    $ssh->exec("chmod -R 755 {$path}");
    $ssh->exec("cd {$path}\nwget http:\/\/120.115.2.90\/uploads\/my_xoops.zip");

    $ssh->exec("unzip {$path}/my_xoops.zip -d {$home}");

    if (!file_exists("{$path}/mainfile.php")) {
        $zip = new dUnzip2("{$path}/my_xoops.zip");
        $zip->getList();
        $zip->unzipAll("{$path}/");
        $zip->close();
    }

    $ssh->exec("chmod -R 755 {$path}");
    $ssh->exec("chmod -R 777 {$path}/xoops_data");
    $ssh->exec("chmod -R 777 {$path}/uploads");
    $ssh->exec("chmod 777 {$path}/mainfile.php");
    $ssh->exec("chmod 777 {$path}/include/license.php");
    $ssh->exec("chmod -R 777 {$path}/themes/default/modules");
    $ssh->exec("chmod -R 777 {$path}/themes/school2015/modules");

    if ($subdir != 'xoops') {
        $ssh->exec("sed -i 's/xx_/{$subdir}_/g' {$path}/xoops_data/data/xoops.sql");
        $ssh->exec("sed -i 's/xx/{$subdir}/g' {$path}/xoops_data/data/secure.php");
    }

    $path = str_replace('/', '\/', $path);
    $xoops_lib = str_replace('/', '\/', $xoops_lib);
    $xoops_data = str_replace('/', '\/', $xoops_data);

    $ssh->exec("sed -i 's/xoops_root_path/{$path}/g' {$path}/mainfile.php");
    $ssh->exec("sed -i 's/xoops_lib_path/{$xoops_lib}/g' {$path}/mainfile.php");
    $ssh->exec("sed -i 's/xoops_data_path/{$xoops_data}/g' {$path}/mainfile.php");

    $ssh->exec("mv {$path}/xoops_data {$xoops_data}");
    $ssh->exec("mv {$path}/xoops_lib {$xoops_lib}");

    $ssh->exec("chmod -R 444 {$path}/mainfile.php");

    $ssh->exec("chown -R {$_COOKIE['ssh_id']}:{$_COOKIE['ssh_id']} {$path}");
    $ssh->exec("chown -R {$_COOKIE['ssh_id']}:{$_COOKIE['ssh_id']} {$xoops_lib}");
    $ssh->exec("chown -R {$_COOKIE['ssh_id']}:{$_COOKIE['ssh_id']} {$xoops_data}");

    $ssh->exec("rm -Rf {$path}/vendor");
    $ssh->exec("rm {$path}/install.php");
    $ssh->exec("rm -f {$path}/my_xoops.zip");
    $ssh->exec("rm {$path}/index.html");
    $ssh->exec("rm {$path}/composer.json");
    $ssh->exec("rm {$path}/composer.lock");

}

function php_install($home = "", $trust_path = "", $xoops_lib = "", $xoops_data = "")
{
    $xoops_path = get_xoops_path();
    foreach ($xoops_path as $key => $value) {
        if (empty($$key)) {
            $$key = $value;
        }
    }

    if (!get_my_xoops($path)) {
        die("無法下載");
    }

    $zip = new dUnzip2("{$path}/my_xoops.zip");
    $zip->getList();
    $zip->unzipAll("{$path}/");
    $zip->close();

    // exec("unzip.exe {$path}/my_xoops.zip");

    delete_directory("{$path}/phpseclib");
    unlink("{$path}/my_xoops.zip");

    chmod_R("{$path}", 0644, 0755);
    chmod_R("{$path}/xoops_data", 0777, 0777);
    chmod_R("{$path}/uploads", 0777, 0777);
    chmod_R("{$path}/mainfile.php", 0777, 0777);
    chmod_R("{$path}/themes/school2019/modules", 0777, 0777);

    if ($subdir != 'xoops') {
        php_sed('xx_', "{$subdir}_", "{$path}/xoops_data/data/xoops.sql");
        php_sed('xx', "{$subdir}", "{$path}/xoops_data/data/secure.php");
    }

    php_sed('xoops_root_path', "{$path}", "{$path}/mainfile.php");
    php_sed('xoops_lib_path', "{$xoops_lib}", "{$path}/mainfile.php");
    php_sed('xoops_data_path', "{$xoops_data}", "{$path}/mainfile.php");

    move_dir("{$path}/xoops_data", $xoops_data);
    move_dir("{$path}/xoops_lib", $xoops_lib);

    chmod_R("{$path}/mainfile.php", 0444, 0444);
    unlink("{$path}/install.php");
    unlink("{$path}/index.html");
}

//取得輕鬆架
function get_my_xoops($path)
{
    if (file_exists("{$path}/my_xoops.zip")) {
        return true;
    }

    $url = "http://120.115.2.90/uploads/my_xoops.zip";
    if (function_exists('curl_init')) {
        $ch = curl_init();
        $timeout = 5;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $data = curl_exec($ch);
        curl_close($ch);
    } elseif (function_exists('file_get_contents')) {
        $data = file_get_contents($url);
    } else {
        $handle = fopen($url, "rb");
        $data = stream_get_contents($handle);
        fclose($handle);
    }

    if (file_exists("{$path}/my_xoops.zip")) {
        return false;
    }
    $openedfile = fopen("{$path}/my_xoops.zip", "w");
    fwrite($openedfile, $data);
    fclose($openedfile);
    if ($data === false) {
        $status = false;
    } else {
        $status = true;
    }
    return $status;
}

function move_dir($old_dir, $new_dir)
{
    mk_dir($new_dir);
    recurse_copy($old_dir, $new_dir);

}

function mk_dir($dir = "")
{
    //若無目錄名稱秀出警告訊息
    if (empty($dir)) {
        redirect_header("index.php", 3, _TAD_NO_DIRNAME);
    }

    //若目錄不存在的話建立目錄
    if (!is_dir($dir)) {
        umask(000);
        //若建立失敗秀出警告訊息
        if (!mkdir($dir, 0777)) {
            redirect_header("index.php", 3, sprintf(_TAD_MKDIR_ERROR, $dir));
        }
    }
}

function chmod_R($path, $filemode, $dirmode)
{

    if (is_dir($path)) {
        if (!chmod($path, $dirmode)) {
            $dirmode_str = decoct($dirmode);
            // print "chmod -R $dirmode_str $path \n";
            return false;
        }
        $dh = opendir($path);
        while (($file = readdir($dh)) !== false) {
            if ($file != '.' && $file != '..') {
                // skip self and parent pointing directories
                $fullpath = $path . '/' . $file;
                chmod_R($fullpath, $filemode, $dirmode);
            }
        }
        closedir($dh);
    } else {
        if (is_link($path)) {
            // print "link '$path' is skipped\n";
            return;
        }
        if (!chmod($path, $filemode)) {
            $filemode_str = decoct($filemode);
            // print "Failed applying filemode '$filemode_str' on file '$path'\n";
            return false;
        }
    }
}

function delete_directory($dirname)
{
    if (is_dir($dirname)) {
        $dir_handle = opendir($dirname);
    }

    if (!$dir_handle) {
        return false;
    }

    while ($file = readdir($dir_handle)) {
        if ($file != "." && $file != "..") {
            if (!is_dir($dirname . "/" . $file)) {
                unlink($dirname . "/" . $file);
            } else {
                delete_directory($dirname . '/' . $file);
            }

        }
    }
    closedir($dir_handle);
    rmdir($dirname);
    return true;
}

function php_sed($search, $replace, $file)
{
    $content = file_get_contents($file);
    $content = str_replace($search, $replace, $content);
    file_put_contents($file, $content);
}

class dUnzip2
{
    public function getVersion()
    {
        return "2.662";
    }
    // Public
    public $fileName;
    public $lastError;
    public $compressedList; // You will problably use only this one!
    public $centralDirList; // Central dir list... It's a kind of 'extra attributes' for a set of files
    public $endOfCentral; // End of central dir, contains ZIP Comments
    public $debug;

    // Private
    public $fh;
    public $zipSignature = "\x50\x4b\x03\x04"; // local file header signature
    public $dirSignature = "\x50\x4b\x01\x02"; // central dir header signature
    public $dirSignatureE = "\x50\x4b\x05\x06"; // end of central dir signature

    // Public
    public function __construct($fileName)
    {
        $this->fileName = $fileName;
        $this->compressedList =
        $this->centralDirList =
        $this->endOfCentral = array();
    }

    public function getList($stopOnFile = false)
    {
        if (sizeof($this->compressedList)) {
            $this->debugMsg(1, "Returning already loaded file list.");
            return $this->compressedList;
        }

        // Open file, and set file handler
        $fh = fopen($this->fileName, "r");
        $this->fh = &$fh;
        if (!$fh) {
            $this->debugMsg(2, "Failed to load file.");
            return false;
        }

        $this->debugMsg(1, "Loading list from 'End of Central Dir' index list...");
        if (!$this->_loadFileListByEOF($fh, $stopOnFile)) {
            $this->debugMsg(1, "Failed! Trying to load list looking for signatures...");
            if (!$this->_loadFileListBySignatures($fh, $stopOnFile)) {
                $this->debugMsg(1, "Failed! Could not find any valid header.");
                $this->debugMsg(2, "ZIP File is corrupted or empty");
                return false;
            }
        }

        if ($this->debug) {
            #------- Debug compressedList
            $kkk = 0;
            echo "<table border='0' style='font: 11px Verdana; border: 1px solid #000'>";
            foreach ($this->compressedList as $fileName => $item) {
                if (!$kkk && $kkk = 1) {
                    echo "<tr style='background: #ADA'>";
                    foreach ($item as $fieldName => $value) {
                        echo "<td>$fieldName</td>";
                    }

                    echo '</tr>';
                }
                echo "<tr style='background: #CFC'>";
                foreach ($item as $fieldName => $value) {
                    if ($fieldName == 'lastmod_datetime') {
                        echo "<td title='$fieldName' nowrap='nowrap'>" . date("d/m/Y H:i:s", $value) . "</td>";
                    } else {
                        echo "<td title='$fieldName' nowrap='nowrap'>$value</td>";
                    }

                }
                echo "</tr>";
            }
            echo "</table>";

            #------- Debug centralDirList
            $kkk = 0;
            if (sizeof($this->centralDirList)) {
                echo "<table border='0' style='font: 11px Verdana; border: 1px solid #000'>";
                foreach ($this->centralDirList as $fileName => $item) {
                    if (!$kkk && $kkk = 1) {
                        echo "<tr style='background: #AAD'>";
                        foreach ($item as $fieldName => $value) {
                            echo "<td>$fieldName</td>";
                        }

                        echo '</tr>';
                    }
                    echo "<tr style='background: #CCF'>";
                    foreach ($item as $fieldName => $value) {
                        if ($fieldName == 'lastmod_datetime') {
                            echo "<td title='$fieldName' nowrap='nowrap'>" . date("d/m/Y H:i:s", $value) . "</td>";
                        } else {
                            echo "<td title='$fieldName' nowrap='nowrap'>$value</td>";
                        }

                    }
                    echo "</tr>";
                }
                echo "</table>";
            }

            #------- Debug endOfCentral
            $kkk = 0;
            if (sizeof($this->endOfCentral)) {
                echo "<table border='0' style='font: 11px Verdana' style='border: 1px solid #000'>";
                echo "<tr style='background: #DAA'><td colspan='2'>dUnzip - End of file</td></tr>";
                foreach ($this->endOfCentral as $field => $value) {
                    echo "<tr>";
                    echo "<td style='background: #FCC'>$field</td>";
                    echo "<td style='background: #FDD'>$value</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        }

        return $this->compressedList;
    }
    public function getExtraInfo($compressedFileName)
    {
        return
        isset($this->centralDirList[$compressedFileName]) ?
        $this->centralDirList[$compressedFileName] :
        false;
    }
    public function getZipInfo($detail = false)
    {
        return $detail ?
        $this->endOfCentral[$detail] :
        $this->endOfCentral;
    }

    public function unzip($compressedFileName, $targetFileName = false, $applyChmod = 0777)
    {
        if (!sizeof($this->compressedList)) {
            $this->debugMsg(1, "Trying to unzip before loading file list... Loading it!");
            $this->getList(false, $compressedFileName);
        }

        $fdetails = &$this->compressedList[$compressedFileName];
        if (!isset($this->compressedList[$compressedFileName])) {
            $this->debugMsg(2, "File '<b>$compressedFileName</b>' is not compressed in the zip.");
            return false;
        }
        if (substr($compressedFileName, -1) == "/") {
            $this->debugMsg(2, "Trying to unzip a folder name '<b>$compressedFileName</b>'.");
            return false;
        }
        if (!$fdetails['uncompressed_size']) {
            $this->debugMsg(1, "File '<b>$compressedFileName</b>' is empty.");
            return $targetFileName ?
            file_put_contents($targetFileName, "") :
            "";
        }

        fseek($this->fh, $fdetails['contents-startOffset']);
        $toUncompress = fread($this->fh, $fdetails['compressed_size']);
        $ret = $this->uncompress(
            $toUncompress,
            $fdetails['compression_method'],
            $fdetails['uncompressed_size'],
            $targetFileName
        );
        unset($toUncompress);
        if ($applyChmod && $targetFileName) {
            chmod($targetFileName, 0777);
        }

        return $ret;
    }
    public function unzipAll($targetDir = false, $baseDir = "", $maintainStructure = true, $applyChmod = 0777)
    {
        if ($targetDir === false) {
            $targetDir = dirname($_SERVER['SCRIPT_FILENAME']) . "/";
        }

        if (substr($targetDir, -1) != "/") {
            $targetDir .= "/";
        }

        $lista = $this->getList();
        if (sizeof($lista)) {
            foreach ($lista as $fileName => $trash) {
                $dirname = dirname($fileName);
                $outDN = "$targetDir/$dirname";

                if (substr($dirname, 0, strlen($baseDir)) != $baseDir) {
                    continue;
                }

                if (!is_dir($outDN) && $maintainStructure) {
                    $str = "";
                    $folders = explode("/", $dirname);
                    foreach ($folders as $folder) {
                        $str = $str ? "$str/$folder" : $folder;
                        if (!is_dir("$targetDir/$str")) {
                            $this->debugMsg(1, "Creating folder: $targetDir/$str");
                            mkdir("$targetDir/$str");
                            if ($applyChmod) {
                                chmod("$targetDir/$str", $applyChmod);
                            }

                        }
                    }
                }
                if (substr($fileName, -1, 1) == "/") {
                    continue;
                }

                $maintainStructure ?
                $this->unzip($fileName, "$targetDir/$fileName", $applyChmod) :
                $this->unzip($fileName, "$targetDir/" . basename($fileName), $applyChmod);
            }
        }

    }

    public function close()
    {
        // Free the file resource
        if ($this->fh) {
            fclose($this->fh);
        }

    }
    public function __destroy()
    {
        $this->close();
    }

    // Private (you should NOT call these methods):
    public function uncompress(&$content, $mode, $uncompressedSize, $targetFileName = false)
    {
        switch ($mode) {
            case 0:
                // Not compressed
                return $targetFileName ?
                file_put_contents($targetFileName, $content) :
                $content;
            case 1:
                $this->debugMsg(2, "Shrunk mode is not supported... yet?");
                return false;
            case 2:
            case 3:
            case 4:
            case 5:
                $this->debugMsg(2, "Compression factor " . ($mode - 1) . " is not supported... yet?");
                return false;
            case 6:
                $this->debugMsg(2, "Implode is not supported... yet?");
                return false;
            case 7:
                $this->debugMsg(2, "Tokenizing compression algorithm is not supported... yet?");
                return false;
            case 8:
                // Deflate
                return $targetFileName ?
                file_put_contents($targetFileName, gzinflate($content, $uncompressedSize)) :
                gzinflate($content, $uncompressedSize);
            case 9:
                $this->debugMsg(2, "Enhanced Deflating is not supported... yet?");
                return false;
            case 10:
                $this->debugMsg(2, "PKWARE Date Compression Library Impoloding is not supported... yet?");
                return false;
            case 12:
                // Bzip2
                return $targetFileName ?
                file_put_contents($targetFileName, bzdecompress($content)) :
                bzdecompress($content);
            case 18:
                $this->debugMsg(2, "IBM TERSE is not supported... yet?");
                return false;
            default:
                $this->debugMsg(2, "Unknown uncompress method: $mode");
                return false;
        }
    }
    public function debugMsg($level, $string)
    {
        if ($this->debug) {
            if ($level == 1) {
                echo "<b style='color: #777'>dUnzip2:</b> $string<br>";
            }

            if ($level == 2) {
                echo "<b style='color: #F00'>dUnzip2:</b> $string<br>";
            }

        }
        $this->lastError = $string;
    }
    public function getLastError()
    {
        return $this->lastError;
    }

    public function _loadFileListByEOF(&$fh, $stopOnFile = false)
    {
        // Check if there's a valid Central Dir signature.
        // Let's consider a file comment smaller than 1024 characters...
        // Actually, it length can be 65536.. But we're not going to support it.

        for ($x = 0; $x < 1024; $x++) {
            fseek($fh, -22 - $x, SEEK_END);

            $signature = fread($fh, 4);
            if ($signature == $this->dirSignatureE) {
                // If found EOF Central Dir
                $eodir['disk_number_this'] = unpack("v", fread($fh, 2)); // number of this disk
                $eodir['disk_number'] = unpack("v", fread($fh, 2)); // number of the disk with the start of the central directory
                $eodir['total_entries_this'] = unpack("v", fread($fh, 2)); // total number of entries in the central dir on this disk
                $eodir['total_entries'] = unpack("v", fread($fh, 2)); // total number of entries in
                $eodir['size_of_cd'] = unpack("V", fread($fh, 4)); // size of the central directory
                $eodir['offset_start_cd'] = unpack("V", fread($fh, 4)); // offset of start of central directory with respect to the starting disk number
                $zipFileCommentLenght = unpack("v", fread($fh, 2)); // zipfile comment length
                $eodir['zipfile_comment'] = $zipFileCommentLenght[1] ? fread($fh, $zipFileCommentLenght[1]) : ''; // zipfile comment
                $this->endOfCentral = array(
                    'disk_number_this' => $eodir['disk_number_this'][1],
                    'disk_number' => $eodir['disk_number'][1],
                    'total_entries_this' => $eodir['total_entries_this'][1],
                    'total_entries' => $eodir['total_entries'][1],
                    'size_of_cd' => $eodir['size_of_cd'][1],
                    'offset_start_cd' => $eodir['offset_start_cd'][1],
                    'zipfile_comment' => $eodir['zipfile_comment'],
                );

                // Then, load file list
                fseek($fh, $this->endOfCentral['offset_start_cd']);
                $signature = fread($fh, 4);

                while ($signature == $this->dirSignature) {
                    $dir['version_madeby'] = unpack("v", fread($fh, 2)); // version made by
                    $dir['version_needed'] = unpack("v", fread($fh, 2)); // version needed to extract
                    $dir['general_bit_flag'] = unpack("v", fread($fh, 2)); // general purpose bit flag
                    $dir['compression_method'] = unpack("v", fread($fh, 2)); // compression method
                    $dir['lastmod_time'] = unpack("v", fread($fh, 2)); // last mod file time
                    $dir['lastmod_date'] = unpack("v", fread($fh, 2)); // last mod file date
                    $dir['crc-32'] = fread($fh, 4); // crc-32
                    $dir['compressed_size'] = unpack("V", fread($fh, 4)); // compressed size
                    $dir['uncompressed_size'] = unpack("V", fread($fh, 4)); // uncompressed size
                    $fileNameLength = unpack("v", fread($fh, 2)); // filename length
                    $extraFieldLength = unpack("v", fread($fh, 2)); // extra field length
                    $fileCommentLength = unpack("v", fread($fh, 2)); // file comment length
                    $dir['disk_number_start'] = unpack("v", fread($fh, 2)); // disk number start
                    $dir['internal_attributes'] = unpack("v", fread($fh, 2)); // internal file attributes-byte1
                    $dir['external_attributes1'] = unpack("v", fread($fh, 2)); // external file attributes-byte2
                    $dir['external_attributes2'] = unpack("v", fread($fh, 2)); // external file attributes
                    $dir['relative_offset'] = unpack("V", fread($fh, 4)); // relative offset of local header
                    $dir['file_name'] = fread($fh, $fileNameLength[1]); // filename
                    $dir['extra_field'] = $extraFieldLength[1] ? fread($fh, $extraFieldLength[1]) : ''; // extra field
                    $dir['file_comment'] = $fileCommentLength[1] ? fread($fh, $fileCommentLength[1]) : ''; // file comment

                    // Convert the date and time, from MS-DOS format to UNIX Timestamp
                    $BINlastmod_date = str_pad(decbin($dir['lastmod_date'][1]), 16, '0', STR_PAD_LEFT);
                    $BINlastmod_time = str_pad(decbin($dir['lastmod_time'][1]), 16, '0', STR_PAD_LEFT);
                    $lastmod_dateY = bindec(substr($BINlastmod_date, 0, 7)) + 1980;
                    $lastmod_dateM = bindec(substr($BINlastmod_date, 7, 4));
                    $lastmod_dateD = bindec(substr($BINlastmod_date, 11, 5));
                    $lastmod_timeH = bindec(substr($BINlastmod_time, 0, 5));
                    $lastmod_timeM = bindec(substr($BINlastmod_time, 5, 6));
                    $lastmod_timeS = bindec(substr($BINlastmod_time, 11, 5));

                    // Some protection agains attacks...
                    $dir['file_name'] = $this->_decodeFilename($dir['file_name']);
                    if (!$dir['file_name'] = $this->_protect($dir['file_name'])) {
                        continue;
                    }

                    $this->centralDirList[$dir['file_name']] = array(
                        'version_madeby' => $dir['version_madeby'][1],
                        'version_needed' => $dir['version_needed'][1],
                        'general_bit_flag' => str_pad(decbin($dir['general_bit_flag'][1]), 8, '0', STR_PAD_LEFT),
                        'compression_method' => $dir['compression_method'][1],
                        'lastmod_datetime' => mktime($lastmod_timeH, $lastmod_timeM, $lastmod_timeS, $lastmod_dateM, $lastmod_dateD, $lastmod_dateY),
                        'crc-32' => str_pad(dechex(ord($dir['crc-32'][3])), 2, '0', STR_PAD_LEFT) .
                        str_pad(dechex(ord($dir['crc-32'][2])), 2, '0', STR_PAD_LEFT) .
                        str_pad(dechex(ord($dir['crc-32'][1])), 2, '0', STR_PAD_LEFT) .
                        str_pad(dechex(ord($dir['crc-32'][0])), 2, '0', STR_PAD_LEFT),
                        'compressed_size' => $dir['compressed_size'][1],
                        'uncompressed_size' => $dir['uncompressed_size'][1],
                        'disk_number_start' => $dir['disk_number_start'][1],
                        'internal_attributes' => $dir['internal_attributes'][1],
                        'external_attributes1' => $dir['external_attributes1'][1],
                        'external_attributes2' => $dir['external_attributes2'][1],
                        'relative_offset' => $dir['relative_offset'][1],
                        'file_name' => $dir['file_name'],
                        'extra_field' => $dir['extra_field'],
                        'file_comment' => $dir['file_comment'],
                    );
                    $signature = fread($fh, 4);
                }

                // If loaded centralDirs, then try to identify the offsetPosition of the compressed data.
                if ($this->centralDirList) {
                    foreach ($this->centralDirList as $filename => $details) {
                        $i = $this->_getFileHeaderInformation($fh, $details['relative_offset']);
                        $this->compressedList[$filename]['file_name'] = $filename;
                        $this->compressedList[$filename]['compression_method'] = $details['compression_method'];
                        $this->compressedList[$filename]['version_needed'] = $details['version_needed'];
                        $this->compressedList[$filename]['lastmod_datetime'] = $details['lastmod_datetime'];
                        $this->compressedList[$filename]['crc-32'] = $details['crc-32'];
                        $this->compressedList[$filename]['compressed_size'] = $details['compressed_size'];
                        $this->compressedList[$filename]['uncompressed_size'] = $details['uncompressed_size'];
                        $this->compressedList[$filename]['lastmod_datetime'] = $details['lastmod_datetime'];
                        $this->compressedList[$filename]['extra_field'] = $i['extra_field'];
                        $this->compressedList[$filename]['contents-startOffset'] = $i['contents-startOffset'];
                        if (strtolower($stopOnFile) == strtolower($filename)) {
                            break;
                        }

                    }
                }

                return true;
            }
        }
        return false;
    }
    public function _loadFileListBySignatures(&$fh, $stopOnFile = false)
    {
        fseek($fh, 0);

        $return = false;
        for (;;) {
            $details = $this->_getFileHeaderInformation($fh);
            if (!$details) {
                $this->debugMsg(1, "Invalid signature. Trying to verify if is old style Data Descriptor...");
                fseek($fh, 12 - 4, SEEK_CUR); // 12: Data descriptor - 4: Signature (that will be read again)
                $details = $this->_getFileHeaderInformation($fh);
            }
            if (!$details) {
                $this->debugMsg(1, "Still invalid signature. Probably reached the end of the file.");
                break;
            }
            $filename = $details['file_name'];
            $this->compressedList[$filename] = $details;
            $return = true;
            if (strtolower($stopOnFile) == strtolower($filename)) {
                break;
            }

        }

        return $return;
    }
    public function _getFileHeaderInformation(&$fh, $startOffset = false)
    {
        if ($startOffset !== false) {
            fseek($fh, $startOffset);
        }

        $signature = fread($fh, 4);
        if ($signature == $this->zipSignature) {
            # $this->debugMsg(1, "Zip Signature!");

            // Get information about the zipped file
            $file['version_needed'] = unpack("v", fread($fh, 2)); // version needed to extract
            $file['general_bit_flag'] = unpack("v", fread($fh, 2)); // general purpose bit flag
            $file['compression_method'] = unpack("v", fread($fh, 2)); // compression method
            $file['lastmod_time'] = unpack("v", fread($fh, 2)); // last mod file time
            $file['lastmod_date'] = unpack("v", fread($fh, 2)); // last mod file date
            $file['crc-32'] = fread($fh, 4); // crc-32
            $file['compressed_size'] = unpack("V", fread($fh, 4)); // compressed size
            $file['uncompressed_size'] = unpack("V", fread($fh, 4)); // uncompressed size
            $fileNameLength = unpack("v", fread($fh, 2)); // filename length
            $extraFieldLength = unpack("v", fread($fh, 2)); // extra field length
            $file['file_name'] = fread($fh, $fileNameLength[1]); // filename
            $file['extra_field'] = $extraFieldLength[1] ? fread($fh, $extraFieldLength[1]) : ''; // extra field
            $file['contents-startOffset'] = ftell($fh);

            // Bypass the whole compressed contents, and look for the next file
            fseek($fh, $file['compressed_size'][1], SEEK_CUR);

            // Convert the date and time, from MS-DOS format to UNIX Timestamp
            $BINlastmod_date = str_pad(decbin($file['lastmod_date'][1]), 16, '0', STR_PAD_LEFT);
            $BINlastmod_time = str_pad(decbin($file['lastmod_time'][1]), 16, '0', STR_PAD_LEFT);
            $lastmod_dateY = bindec(substr($BINlastmod_date, 0, 7)) + 1980;
            $lastmod_dateM = bindec(substr($BINlastmod_date, 7, 4));
            $lastmod_dateD = bindec(substr($BINlastmod_date, 11, 5));
            $lastmod_timeH = bindec(substr($BINlastmod_time, 0, 5));
            $lastmod_timeM = bindec(substr($BINlastmod_time, 5, 6));
            $lastmod_timeS = bindec(substr($BINlastmod_time, 11, 5));

            // Some protection agains attacks...
            $file['file_name'] = $this->_decodeFilename($file['file_name']);
            if (!$file['file_name'] = $this->_protect($file['file_name'])) {
                return false;
            }

            // Mount file table
            $i = array(
                'file_name' => $file['file_name'],
                'compression_method' => $file['compression_method'][1],
                'version_needed' => $file['version_needed'][1],
                'lastmod_datetime' => mktime($lastmod_timeH, $lastmod_timeM, $lastmod_timeS, $lastmod_dateM, $lastmod_dateD, $lastmod_dateY),
                'crc-32' => str_pad(dechex(ord($file['crc-32'][3])), 2, '0', STR_PAD_LEFT) .
                str_pad(dechex(ord($file['crc-32'][2])), 2, '0', STR_PAD_LEFT) .
                str_pad(dechex(ord($file['crc-32'][1])), 2, '0', STR_PAD_LEFT) .
                str_pad(dechex(ord($file['crc-32'][0])), 2, '0', STR_PAD_LEFT),
                'compressed_size' => $file['compressed_size'][1],
                'uncompressed_size' => $file['uncompressed_size'][1],
                'extra_field' => $file['extra_field'],
                'general_bit_flag' => str_pad(decbin($file['general_bit_flag'][1]), 8, '0', STR_PAD_LEFT),
                'contents-startOffset' => $file['contents-startOffset'],
            );
            return $i;
        }
        return false;
    }

    public function _decodeFilename($filename)
    {
        $from = "\xb7\xb5\xb6\xc7\x8e\x8f\x92\x80\xd4\x90\xd2\xd3\xde\xd6\xd7\xd8\xd1\xa5\xe3\xe0" .
            "\xe2\xe5\x99\x9d\xeb\xe9\xea\x9a\xed\xe8\xe1\x85\xa0\x83\xc6\x84\x86\x91\x87\x8a" .
            "\x82\x88\x89\x8d\xa1\x8c\x8b\xd0\xa4\x95\xa2\x93\xe4\x94\x9b\x97\xa3\x96\xec\xe7" .
            "\x98ï";
        $to = "ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûýþÿ´";

        return strtr($filename, $from, $to);
    }
    public function _protect($fullPath)
    {
        // Known hack-attacks (filename like):
        //   /home/usr
        //   ../../home/usr
        //   folder/../../../home/usr
        //   sample/(x0)../home/usr

        $fullPath = strtr($fullPath, ":*<>|\"\x0\\", "......./");
        while ($fullPath[0] == "/") {
            $fullPath = substr($fullPath, 1);
        }

        if (substr($fullPath, -1) == "/") {
            $base = '';
            $fullPath = substr($fullPath, 0, -1);
        } else {
            $base = basename($fullPath);
            $fullPath = dirname($fullPath);
        }

        $parts = explode("/", $fullPath);
        $lastIdx = false;
        foreach ($parts as $idx => $part) {
            if ($part == ".") {
                unset($parts[$idx]);
            } elseif ($part == "..") {
                unset($parts[$idx]);
                if ($lastIdx !== false) {
                    unset($parts[$lastIdx]);
                }
            } elseif ($part === '') {
                unset($parts[$idx]);
            } else {
                $lastIdx = $idx;
            }
        }

        $fullPath = sizeof($parts) ? implode("/", $parts) . "/" : "";
        return $fullPath . $base;
    }
}

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    mk_dir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                recurse_copy($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}
