<?php
require XOOPS_ROOT_PATH . '/themes/school2022/bg_config.php';
$i = 0;

//背景底圖2
$i++;
$theme_config[$i]['name'] = "bg_bg2";
$theme_config[$i]['text'] = TF_BG_BG2;
$theme_config[$i]['desc'] = TF_BG_BG2_DESC;
$theme_config[$i]['type'] = "bg_file";
$theme_config[$i]['default'] = "";
$theme_config[$i]['options'] = $bg_file;
$theme_config[$i]['repeat'] = "no-repeat";
$theme_config[$i]['position'] = "left top";
$theme_config[$i]['size'] = "contain";

//背景底圖3
$i++;
$theme_config[$i]['name'] = "bg_bg3";
$theme_config[$i]['text'] = TF_BG_BG3;
$theme_config[$i]['desc'] = TF_BG_BG3_DESC;
$theme_config[$i]['type'] = "bg_file";
$theme_config[$i]['default'] = "";
$theme_config[$i]['options'] = $bg_file;
$theme_config[$i]['repeat'] = "no-repeat";
$theme_config[$i]['position'] = "left top";
$theme_config[$i]['size'] = "auto";
